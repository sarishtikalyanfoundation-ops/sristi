import { Link } from 'wouter';
import { Facebook, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-foreground text-background mt-20">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* About Section */}
          <div>
            <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
              <div className="w-6 h-6 bg-primary rounded-full"></div>
              Sristi Kalyan
            </h3>
            <p className="text-sm opacity-80">
              Empowering underprivileged communities through education, healthcare, women empowerment, and environmental sustainability.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/about">
                  <a className="hover:text-primary transition-colors">About Us</a>
                </Link>
              </li>
              <li>
                <Link href="/programs">
                  <a className="hover:text-primary transition-colors">Programs</a>
                </Link>
              </li>
              <li>
                <Link href="/get-involved">
                  <a className="hover:text-primary transition-colors">Get Involved</a>
                </Link>
              </li>
              <li>
                <Link href="/blog">
                  <a className="hover:text-primary transition-colors">Blog</a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-semibold mb-4">Support Us</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/donate">
                  <a className="hover:text-primary transition-colors">Donate</a>
                </Link>
              </li>
              <li>
                <Link href="/get-involved">
                  <a className="hover:text-primary transition-colors">Volunteer</a>
                </Link>
              </li>
              <li>
                <a href="#" className="hover:text-primary transition-colors">Partner With Us</a>
              </li>
              <li>
                <a href="#" className="hover:text-primary transition-colors">Careers</a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <Phone size={16} className="mt-0.5 flex-shrink-0" />
                <a href="tel:+919110596321" className="hover:text-primary transition-colors">
                  +91-9110596321
                </a>
              </li>
              <li className="flex items-start gap-2">
                <Mail size={16} className="mt-0.5 flex-shrink-0" />
                <a href="mailto:Sarishtikalyanfoundation@gmail.com" className="hover:text-primary transition-colors break-all">
                  Sarishtikalyanfoundation@gmail.com
                </a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin size={16} className="mt-0.5 flex-shrink-0" />
                <span>Sristi Kalyan Foundation</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Social Links */}
        <div className="border-t border-background/20 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <a href="#" className="hover:text-primary transition-colors" title="Facebook">
              <Facebook size={20} />
            </a>
            <a href="#" className="hover:text-primary transition-colors" title="Instagram">
              <Instagram size={20} />
            </a>
            <a href="#" className="hover:text-primary transition-colors" title="LinkedIn">
              <Linkedin size={20} />
            </a>
          </div>

          <p className="text-sm opacity-70">
            © {currentYear} Sristi Kalyan Foundation. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
