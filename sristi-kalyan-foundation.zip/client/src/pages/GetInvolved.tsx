import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Users, Briefcase, Heart, ArrowRight } from 'lucide-react';

export default function GetInvolved() {
  const volunteerOpportunities = [
    { title: 'Teaching & Mentoring', description: 'Help children with their studies and provide academic guidance.' },
    { title: 'Health & Awareness Camps', description: 'Support health check-ups and awareness sessions.' },
    { title: 'Environment Drives', description: 'Participate in tree plantation and cleanliness campaigns.' },
    { title: 'Event & Campaign Support', description: 'Help organize and manage community events.' }
  ];

  const partnershipAreas = [
    { title: 'CSR Projects', description: 'Corporate social responsibility initiatives aligned with our mission.' },
    { title: 'Community Development', description: 'Long-term partnership for sustainable community development.' },
    { title: 'Skill & Livelihood', description: 'Collaborate on skill development and livelihood programs.' },
    { title: 'Healthcare Initiatives', description: 'Partner with us to improve community health outcomes.' }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-secondary/10 to-background">
        <div className="container">
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6">Get Involved</h1>
          <p className="text-xl text-muted-foreground max-w-3xl">
            Join us in our mission to empower communities. Whether you want to volunteer your time or partner with us, there are many ways to make a difference.
          </p>
        </div>
      </section>

      {/* Volunteer Section */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-12">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-secondary/10 rounded-lg">
                  <Users className="text-secondary" size={32} />
                </div>
                <h2 className="text-4xl font-bold">Volunteer With Us</h2>
              </div>
              <p className="text-lg text-muted-foreground mb-6">
                Join hands with us to create real impact. Volunteers play a vital role in implementing programs, spreading awareness, and connecting with communities.
              </p>
              <p className="text-muted-foreground mb-8">
                Whether you have a few hours a week or can commit to longer-term projects, we have opportunities for everyone. Your skills, passion, and dedication can transform lives.
              </p>
              <Link href="/contact">
                <a>
                  <Button className="btn-primary flex items-center gap-2">
                    Fill out the Volunteer Form <ArrowRight size={18} />
                  </Button>
                </a>
              </Link>
            </div>
            <div className="bg-gradient-to-br from-secondary/20 to-accent/20 rounded-lg p-8 h-96 flex items-center justify-center">
              <div className="text-center">
                <Users className="text-secondary mx-auto mb-4" size={64} />
                <p className="text-lg font-semibold text-foreground">Make a Difference</p>
              </div>
            </div>
          </div>

          <div className="bg-card rounded-lg p-8 mb-12">
            <h3 className="text-2xl font-bold mb-6">Volunteer Opportunities</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {volunteerOpportunities.map((opportunity, index) => (
                <div key={index} className="border border-border rounded-lg p-6">
                  <h4 className="font-bold text-lg mb-2">{opportunity.title}</h4>
                  <p className="text-muted-foreground">{opportunity.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Partnership Section */}
      <section className="py-16 md:py-24 bg-card">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-12">
            <div className="bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg p-8 h-96 flex items-center justify-center order-2 md:order-1">
              <div className="text-center">
                <Briefcase className="text-primary mx-auto mb-4" size={64} />
                <p className="text-lg font-semibold text-foreground">Strategic Partnerships</p>
              </div>
            </div>
            <div className="order-1 md:order-2">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Briefcase className="text-primary" size={32} />
                </div>
                <h2 className="text-4xl font-bold">Partner With Us</h2>
              </div>
              <p className="text-lg text-muted-foreground mb-6">
                We welcome partnerships with corporates, institutions, and organizations aligned with our mission.
              </p>
              <p className="text-muted-foreground mb-8">
                Together, we can create sustainable impact at scale. Whether through CSR initiatives, resource sharing, or collaborative programs, your partnership can help us reach more communities and create lasting change.
              </p>
              <Link href="/contact">
                <a>
                  <Button className="btn-primary flex items-center gap-2">
                    Contact us for partnership opportunities <ArrowRight size={18} />
                  </Button>
                </a>
              </Link>
            </div>
          </div>

          <div className="bg-background rounded-lg p-8">
            <h3 className="text-2xl font-bold mb-6">Partnership Areas</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {partnershipAreas.map((area, index) => (
                <div key={index} className="border border-border rounded-lg p-6">
                  <h4 className="font-bold text-lg mb-2">{area.title}</h4>
                  <p className="text-muted-foreground">{area.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Why Join Section */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <h2 className="section-title text-center mb-12">Why Join Us?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="card-warm">
              <Heart className="text-primary mb-4" size={40} />
              <h3 className="text-xl font-bold mb-3">Make Real Impact</h3>
              <p className="text-muted-foreground">Your contribution directly impacts the lives of underprivileged communities and creates lasting change.</p>
            </div>
            <div className="card-warm">
              <Users className="text-secondary mb-4" size={40} />
              <h3 className="text-xl font-bold mb-3">Join a Community</h3>
              <p className="text-muted-foreground">Be part of a passionate community of changemakers working towards social transformation.</p>
            </div>
            <div className="card-warm">
              <Briefcase className="text-accent mb-4" size={40} />
              <h3 className="text-xl font-bold mb-3">Grow & Learn</h3>
              <p className="text-muted-foreground">Develop new skills, gain experience, and grow personally while contributing to social good.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
