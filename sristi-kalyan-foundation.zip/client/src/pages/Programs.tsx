import { BookOpen, Users, Heart, Leaf, CheckCircle } from 'lucide-react';

export default function Programs() {
  const programs = [
    {
      icon: BookOpen,
      title: 'Education & Child Development',
      tagline: 'Break the cycle of poverty through learning.',
      description: 'We believe education is the foundation of social transformation. Our programs focus on providing quality education and support to underprivileged children.',
      activities: [
        'Free tuition & remedial classes for underprivileged children',
        'School admission & dropout prevention support',
        'Distribution of books, uniforms & digital learning tools',
        'Career guidance & skill orientation for youth'
      ],
      impact: 'Improved learning outcomes, confidence, and future opportunities for children.',
      image: 'https://private-us-east-1.manuscdn.com/sessionFile/zJEFH5twc4hB8R1C6VhpWI/sandbox/dPEwpQJePLmKf3q1zJ7e70-img-2_1772090161000_na1fn_ZWR1Y2F0aW9uLXNlY3Rpb24.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvekpFRkg1dHdjNGhCOFIxQzZWaHBXSS9zYW5kYm94L2RQRXdwUUplUExtS2YzcTF6SjdlNzAtaW1nLTJfMTc3MjA5MDE2MTAwMF9uYTFmbl9aV1IxWTJGMGFXOXVMWE5sWTNScGIyNC5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=g2iRaWwjY4i9a~aCoE11HlDfkMUAl9UmGNcuCnHOX4fWH-dzG~D-u9FXZEWGMknNQSExnzkIq7AOKTqRROFqrUdjailmXex96pw37MQwVCNLZ6E2veeGtvIDstrvBdn9EG6P7LaSab12aRydd2j6e4ok92bl~ArminoJv3WekEKdB3PFzbmPAv2~~hsLczYExtu5vLD-AQBPs9ohjd5xTPlPJTB9U19w3BLjSZTjGqmE7NzLzeulzJTalSSFNzPeMU5U5DQ5cxCOiby~FoamMP2OKiyciSEmdyNqsu9h4DiT1ND~Hob8we9qH8ulJck1d5ntHrJSMAAHQI7ogn70yg__',
      color: 'from-orange-100 to-amber-50'
    },
    {
      icon: Users,
      title: 'Women Empowerment & Livelihood',
      tagline: 'Empowered women lead empowered families.',
      description: 'We are committed to enabling financial independence and leadership among women through comprehensive skill development and support programs.',
      activities: [
        'Skill development & vocational training (tailoring, digital literacy, handicrafts)',
        'Self-help group (SHG) formation & mentoring',
        'Entrepreneurship & financial literacy programs',
        'Legal rights & health awareness sessions'
      ],
      impact: 'Financial independence, leadership, and social confidence among women.',
      image: 'https://private-us-east-1.manuscdn.com/sessionFile/zJEFH5twc4hB8R1C6VhpWI/sandbox/dPEwpQJePLmKf3q1zJ7e70-img-3_1772090157000_na1fn_d29tZW4tZW1wb3dlcm1lbnQ.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvekpFRkg1dHdjNGhCOFIxQzZWaHBXSS9zYW5kYm94L2RQRXdwUUplUExtS2YzcTF6SjdlNzAtaW1nLTNfMTc3MjA5MDE1NzAwMF9uYTFmbl9kMjl0Wlc0dFpXMXdiM2RsY20xbGJuUS5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=vgBg5vpOyM9RtMlNhlXg69bS1qN3u-yJyIv469yQqjOTgMAlyjBmtBQy7x8qjAJxnMRrY0vOGkfDg2ISHZgqnwQXQl9nWWQ8j17UN63xXObsKQcwEvA-xqiH0c~eDciu3GlSjXd78vRcM4s-jmIz9lGxnoPhIYTgZrcto0HU-pfGqYrhiEYpNTK1zIkWzbSAmC-2fBxs1zLihQ~TWLN5w0RQ4DrgeU28igADSwScGBbfEbSyIw0LB7Lsvr1gN8pyZfV7-LJSXMowtGRQ5VkRQ97zXtGtDnG63d~52d1VRd3Hcj0AtkQqmET7RchgAX92865Fe7WRNCyvnjoN5DLtTg__',
      color: 'from-amber-100 to-orange-50'
    },
    {
      icon: Heart,
      title: 'Health, Nutrition & Wellness',
      tagline: 'Good health is the backbone of a strong community.',
      description: 'We work to improve community health and awareness through comprehensive health programs and preventive care initiatives.',
      activities: [
        'Free medical & health check-up camps',
        'Nutrition awareness for women & children',
        'Menstrual hygiene education & sanitary kit distribution',
        'Mental health & wellness awareness sessions'
      ],
      impact: 'Healthier families and preventive healthcare awareness.',
      image: 'https://private-us-east-1.manuscdn.com/sessionFile/zJEFH5twc4hB8R1C6VhpWI/sandbox/dPEwpQJePLmKf3q1zJ7e70-img-4_1772090163000_na1fn_aGVhbHRoLXdlbGxuZXNz.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvekpFRkg1dHdjNGhCOFIxQzZWaHBXSS9zYW5kYm94L2RQRXdwUUplUExtS2YzcTF6SjdlNzAtaW1nLTRfMTc3MjA5MDE2MzAwMF9uYTFmbl9hR1ZoYkhSb0xYZGxiR3h1WlhOei5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=tlwj85J~jSf9ZgenQfsDzCygDMHOmi94p8JpnfD3kCz3n2p3NPjsPq6PE6LlUtpi3c5-Vgjye5wJ3-PwVcLTXr4VtJ7JyQ2grZzmRJZmzhuwuNAt7TN4qob5hgNucXnVGB~5CVFpeEPlBZfVoMzry27GWAXbwhmgQPpae6ouEM-P4rgFyTT2oqibbJWHjQ6MB2FzQyixrxBEVbW5MeyZ~UdAVSvCOHPlFJwhMku-WGitX9WKTbGteqSf-pUO9LtVUJ~ukpau9TkV3ow4YwlV60lPcOyvKBLllq6bIBoKBMN8W5gqS0qh9yl-tGhkb5PztC5M0r15Fdc3l0fAH6NEKA__',
      color: 'from-green-100 to-emerald-50'
    },
    {
      icon: Leaf,
      title: 'Environment & Sustainability',
      tagline: 'Protecting nature for future generations.',
      description: 'We promote responsible living and ecological balance through comprehensive environmental conservation and awareness programs.',
      activities: [
        'Tree plantation & green drives',
        'Cleanliness and waste management campaigns',
        'Plastic-free awareness initiatives',
        'Environmental education programs for children & youth'
      ],
      impact: 'Cleaner surroundings and eco-conscious communities.',
      image: 'https://private-us-east-1.manuscdn.com/sessionFile/zJEFH5twc4hB8R1C6VhpWI/sandbox/dPEwpQJePLmKf3q1zJ7e70-img-5_1772090161000_na1fn_ZW52aXJvbm1lbnQtc3VzdGFpbmFiaWxpdHk.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvekpFRkg1dHdjNGhCOFIxQzZWaHBXSS9zYW5kYm94L2RQRXdwUUplUExtS2YzcTF6SjdlNzAtaW1nLTVfMTc3MjA5MDE2MTAwMF9uYTFmbl9aVzUyYVhKdmJtMWxiblF0YzNWemRHRnBibUZpYVd4cGRIay5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=RzudDaYzI2voWgeg92LHVUu5v12IXuKGU4zlPzmz7hTsrIJrTA~Hf-~410OxCp~wBNSHcT9WRWmVoG5oKPfyQclxq4tIcPynwkT8MuCyIEqvHBqJ89k~Pe7r5AiSeO5tHogmz8RIzPMb62stajdRUSo~HedANUOqfQiQrCUvLkcO3sm-THZ03HKjpiE288CwgzQ8jCUFFXKHNhVdagzsJI2akU5I2IyChEp~OF4L5EUiR7lzvrvUgXWiS8A7uwxwrGkRZIEc2vzuCwZ4hHXZRQl~aYHvRk80stK0rU0Stprcq3ItsKjVNk252Bu8beIZymUstjez8Yhga0M~DlGEJA__',
      color: 'from-green-100 to-lime-50'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-primary/10 to-background">
        <div className="container">
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6">Our Programs</h1>
          <p className="text-xl text-muted-foreground max-w-3xl">
            We implement comprehensive programs across four key areas to create sustainable impact in underprivileged communities.
          </p>
        </div>
      </section>

      {/* Programs Detail Section */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="space-y-20">
            {programs.map((program, index) => {
              const Icon = program.icon;
              const isEven = index % 2 === 0;
              return (
                <div key={index} className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                  <div className={isEven ? 'order-1' : 'order-2'}>
                    <div className="flex items-center gap-3 mb-4">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <Icon className="text-primary" size={32} />
                      </div>
                      <div>
                        <h2 className="text-3xl font-bold">{program.title}</h2>
                        <p className="text-primary font-semibold">{program.tagline}</p>
                      </div>
                    </div>
                    <p className="text-lg text-muted-foreground mb-6">{program.description}</p>
                    
                    <div className="mb-8">
                      <h3 className="font-bold text-lg mb-4">Key Activities</h3>
                      <ul className="space-y-3">
                        {program.activities.map((activity, i) => (
                          <li key={i} className="flex items-start gap-3">
                            <CheckCircle className="text-secondary flex-shrink-0 mt-1" size={20} />
                            <span className="text-muted-foreground">{activity}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-accent/10 rounded-lg p-4">
                      <h3 className="font-bold mb-2">Impact Focus</h3>
                      <p className="text-muted-foreground">{program.impact}</p>
                    </div>
                  </div>

                  <div className={`bg-gradient-to-br ${program.color} rounded-lg overflow-hidden h-96 order-${isEven ? '2' : '1'}`}>
                    <img
                      src={program.image}
                      alt={program.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}
