import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { BookOpen, Heart, Users, Leaf, ArrowRight, Check } from 'lucide-react';

export default function Home() {
  const programs = [
    {
      icon: BookOpen,
      title: 'Education & Child Development',
      description: 'Break the cycle of poverty through learning with free tuition, remedial classes, and digital literacy programs.',
      image: 'https://private-us-east-1.manuscdn.com/sessionFile/zJEFH5twc4hB8R1C6VhpWI/sandbox/dPEwpQJePLmKf3q1zJ7e70-img-2_1772090161000_na1fn_ZWR1Y2F0aW9uLXNlY3Rpb24.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvekpFRkg1dHdjNGhCOFIxQzZWaHBXSS9zYW5kYm94L2RQRXdwUUplUExtS2YzcTF6SjdlNzAtaW1nLTJfMTc3MjA5MDE2MTAwMF9uYTFmbl9aV1IxWTJGMGFXOXVMWE5sWTNScGIyNC5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=g2iRaWwjY4i9a~aCoE11HlDfkMUAl9UmGNcuCnHOX4fWH-dzG~D-u9FXZEWGMknNQSExnzkIq7AOKTqRROFqrUdjailmXex96pw37MQwVCNLZ6E2veeGtvIDstrvBdn9EG6P7LaSab12aRydd2j6e4ok92bl~ArminoJv3WekEKdB3PFzbmPAv2~~hsLczYExtu5vLD-AQBPs9ohjd5xTPlPJTB9U19w3BLjSZTjGqmE7NzLzeulzJTalSSFNzPeMU5U5DQ5cxCOiby~FoamMP2OKiyciSEmdyNqsu9h4DiT1ND~Hob8we9qH8ulJck1d5ntHrJSMAAHQI7ogn70yg__',
      color: 'from-orange-100 to-amber-50'
    },
    {
      icon: Users,
      title: 'Women Empowerment & Livelihood',
      description: 'Enable financial independence and leadership through skill development and self-help group formation.',
      image: 'https://private-us-east-1.manuscdn.com/sessionFile/zJEFH5twc4hB8R1C6VhpWI/sandbox/dPEwpQJePLmKf3q1zJ7e70-img-3_1772090157000_na1fn_d29tZW4tZW1wb3dlcm1lbnQ.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvekpFRkg1dHdjNGhCOFIxQzZWaHBXSS9zYW5kYm94L2RQRXdwUUplUExtS2YzcTF6SjdlNzAtaW1nLTNfMTc3MjA5MDE1NzAwMF9uYTFmbl9kMjl0Wlc0dFpXMXdiM2RsY20xbGJuUS5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=vgBg5vpOyM9RtMlNhlXg69bS1qN3u-yJyIv469yQqjOTgMAlyjBmtBQy7x8qjAJxnMRrY0vOGkfDg2ISHZgqnwQXQl9nWWQ8j17UN63xXObsKQcwEvA-xqiH0c~eDciu3GlSjXd78vRcM4s-jmIz9lGxnoPhIYTgZrcto0HU-pfGqYrhiEYpNTK1zIkWzbSAmC-2fBxs1zLihQ~TWLN5w0RQ4DrgeU28igADSwScGBbfEbSyIw0LB7Lsvr1gN8pyZfV7-LJSXMowtGRQ5VkRQ97zXtGtDnG63d~52d1VRd3Hcj0AtkQqmET7RchgAX92865Fe7WRNCyvnjoN5DLtTg__',
      color: 'from-amber-100 to-orange-50'
    },
    {
      icon: Heart,
      title: 'Health, Nutrition & Wellness',
      description: 'Improve community health through free medical camps, nutrition awareness, and mental health programs.',
      image: 'https://private-us-east-1.manuscdn.com/sessionFile/zJEFH5twc4hB8R1C6VhpWI/sandbox/dPEwpQJePLmKf3q1zJ7e70-img-4_1772090163000_na1fn_aGVhbHRoLXdlbGxuZXNz.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvekpFRkg1dHdjNGhCOFIxQzZWaHBXSS9zYW5kYm94L2RQRXdwUUplUExtS2YzcTF6SjdlNzAtaW1nLTRfMTc3MjA5MDE2MzAwMF9uYTFmbl9hR1ZoYkhSb0xYZGxiR3h1WlhOei5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=tlwj85J~jSf9ZgenQfsDzCygDMHOmi94p8JpnfD3kCz3n2p3NPjsPq6PE6LlUtpi3c5-Vgjye5wJ3-PwVcLTXr4VtJ7JyQ2grZzmRJZmzhuwuNAt7TN4qob5hgNucXnVGB~5CVFpeEPlBZfVoMzry27GWAXbwhmgQPpae6ouEM-P4rgFyTT2oqibbJWHjQ6MB2FzQyixrxBEVbW5MeyZ~UdAVSvCOHPlFJwhMku-WGitX9WKTbGteqSf-pUO9LtVUJ~ukpau9TkV3ow4YwlV60lPcOyvKBLllq6bIBoKBMN8W5gqS0qh9yl-tGhkb5PztC5M0r15Fdc3l0fAH6NEKA__',
      color: 'from-green-100 to-emerald-50'
    },
    {
      icon: Leaf,
      title: 'Environment & Sustainability',
      description: 'Promote responsible living through tree plantation, waste management, and environmental education.',
      image: 'https://private-us-east-1.manuscdn.com/sessionFile/zJEFH5twc4hB8R1C6VhpWI/sandbox/dPEwpQJePLmKf3q1zJ7e70-img-5_1772090161000_na1fn_ZW52aXJvbm1lbnQtc3VzdGFpbmFiaWxpdHk.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvekpFRkg1dHdjNGhCOFIxQzZWaHBXSS9zYW5kYm94L2RQRXdwUUplUExtS2YzcTF6SjdlNzAtaW1nLTVfMTc3MjA5MDE2MTAwMF9uYTFmbl9aVzUyYVhKdmJtMWxiblF0YzNWemRHRnBibUZpYVd4cGRIay5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=RzudDaYzI2voWgeg92LHVUu5v12IXuKGU4zlPzmz7hTsrIJrTA~Hf-~410OxCp~wBNSHcT9WRWmVoG5oKPfyQclxq4tIcPynwkT8MuCyIEqvHBqJ89k~Pe7r5AiSeO5tHogmz8RIzPMb62stajdRUSo~HedANUOqfQiQrCUvLkcO3sm-THZ03HKjpiE288CwgzQ8jCUFFXKHNhVdagzsJI2akU5I2IyChEp~OF4L5EUiR7lzvrvUgXWiS8A7uwxwrGkRZIEc2vzuCwZ4hHXZRQl~aYHvRk80stK0rU0Stprcq3ItsKjVNk252Bu8beIZymUstjez8Yhga0M~DlGEJA__',
      color: 'from-green-100 to-lime-50'
    }
  ];

  const whyChooseUs = [
    { title: 'Transparent & Ethical', description: 'Complete transparency in all operations and fund utilization.' },
    { title: 'Community-Based', description: 'Implementation at grassroots level with community participation.' },
    { title: 'Sustainable Impact', description: 'Focus on long-term, sustainable development and self-reliance.' },
    { title: 'SDG Aligned', description: 'Aligned with UN Sustainable Development Goals.' }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://private-us-east-1.manuscdn.com/sessionFile/zJEFH5twc4hB8R1C6VhpWI/sandbox/dPEwpQJePLmKf3q1zJ7e70-img-1_1772090165000_na1fn_aGVyby1tYWlu.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvekpFRkg1dHdjNGhCOFIxQzZWaHBXSS9zYW5kYm94L2RQRXdwUUplUExtS2YzcTF6SjdlNzAtaW1nLTFfMTc3MjA5MDE2NTAwMF9uYTFmbl9hR1Z5YnkxdFlXbHUucG5nP3gtb3NzLXByb2Nlc3M9aW1hZ2UvcmVzaXplLHdfMTkyMCxoXzE5MjAvZm9ybWF0LHdlYnAvcXVhbGl0eSxxXzgwIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk4NzYxNjAwfX19XX0_&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=P7FmXeLIaBq0XR0r2jIF70BSnNbBbS0zEBOGbilfY~zRcl5HRheNSh3jdWaQ08cSHqnQRee~K~fYyy8xxoimKvMhQF9AMzbOPOHxJV8tb-OV5mKoVZs0rXkJsxTLfOVYJ0Rs~Z-AwSat6MlwkYxxXJ2L7I8~DQK4nx5tIWzBs-r2oJjOjTHV4IzxDKcjzqeg~bfV7X3Z1KpgofC2uykvCzmp98uVQL-3COi~Ba0CaJSUFjLOCq5AlsX-Jkwa6NxWNmD0SXoZw-CUjDsZkgJSfZbT1BhYQnP1PLBV6KwyO9qrinzFyjyoC8zuHhAG2AL8louEUHCKP1UGb2AvJfxytg__"
            alt="Community empowerment"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-primary/40 via-primary/20 to-transparent"></div>
        </div>

        <div className="container relative z-10 text-center">
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 drop-shadow-lg">
            Empowering Lives.<br />Building Futures.
          </h1>
          <p className="text-xl md:text-2xl text-white mb-8 max-w-2xl mx-auto drop-shadow-md">
            Education • Women Empowerment • Health • Environment
          </p>
          <p className="text-lg text-white/90 mb-10 max-w-3xl mx-auto drop-shadow-md">
            Sristi Kalyan Foundation is a non-profit organization working to uplift underprivileged communities by creating sustainable opportunities in education, healthcare, women empowerment, and environmental protection.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/donate">
              <a>
                <Button className="btn-primary text-lg px-8 py-6">
                  Donate Now
                </Button>
              </a>
            </Link>
            <Link href="/get-involved">
              <a>
                <Button variant="outline" className="text-lg px-8 py-6 bg-white text-primary hover:bg-white/80">
                  Become a Volunteer
                </Button>
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="section-title">About Sristi Kalyan Foundation</h2>
            <p className="text-lg text-muted-foreground">
              We are committed to bringing meaningful change at the grassroots level. We believe that real development happens when communities are empowered with knowledge, health, skills, and a safe environment. Our initiatives focus on long-term impact, dignity, and self-reliance.
            </p>
          </div>
        </div>
      </section>

      {/* Programs Section */}
      <section className="py-16 md:py-24 bg-card">
        <div className="container">
          <h2 className="section-title text-center mb-12">Our Focus Areas</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {programs.map((program, index) => {
              const Icon = program.icon;
              return (
                <Link key={index} href="/programs">
                  <a className="group cursor-pointer">
                    <div className="card-warm overflow-hidden h-full hover:scale-105 transition-transform duration-300">
                      <div className={`h-48 bg-gradient-to-br ${program.color} overflow-hidden relative`}>
                        <img
                          src={program.image}
                          alt={program.title}
                          className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                        />
                      </div>
                      <div className="p-6">
                        <div className="flex items-center gap-3 mb-3">
                          <div className="p-2 bg-primary/10 rounded-lg">
                            <Icon className="text-primary" size={24} />
                          </div>
                          <h3 className="text-xl font-bold">{program.title}</h3>
                        </div>
                        <p className="text-muted-foreground mb-4">{program.description}</p>
                        <div className="flex items-center gap-2 text-primary font-semibold group-hover:gap-3 transition-all">
                          Learn More <ArrowRight size={18} />
                        </div>
                      </div>
                    </div>
                  </a>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <h2 className="section-title text-center mb-12">Why Choose Us</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {whyChooseUs.map((item, index) => (
              <div key={index} className="card-warm">
                <div className="flex items-start gap-3 mb-3">
                  <Check className="text-primary flex-shrink-0 mt-1" size={24} />
                  <h3 className="font-bold text-lg">{item.title}</h3>
                </div>
                <p className="text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Together, we can transform lives and build a better tomorrow.
          </h2>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/donate">
              <a>
                <Button className="bg-primary-foreground text-primary hover:bg-primary-foreground/80 px-8 py-6 text-lg font-semibold">
                  Donate Now
                </Button>
              </a>
            </Link>
            <Link href="/get-involved">
              <a>
                <Button variant="outline" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10 px-8 py-6 text-lg font-semibold">
                  Volunteer
                </Button>
              </a>
            </Link>
            <Link href="/contact">
              <a>
                <Button variant="outline" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10 px-8 py-6 text-lg font-semibold">
                  Partner With Us
                </Button>
              </a>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
