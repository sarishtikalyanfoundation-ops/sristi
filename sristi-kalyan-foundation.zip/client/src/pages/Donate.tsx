import { Heart, TrendingUp, Users, Leaf } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Donate() {
  const donationOptions = [
    {
      icon: Heart,
      title: 'Child Education',
      description: 'Support free tuition, books, and learning materials for underprivileged children.',
      amount: '₹500'
    },
    {
      icon: Users,
      title: 'Women Livelihood Programs',
      description: 'Enable skill development and entrepreneurship training for women.',
      amount: '₹1000'
    },
    {
      icon: TrendingUp,
      title: 'Health Camps',
      description: 'Support free medical check-ups and health awareness programs.',
      amount: '₹2000'
    },
    {
      icon: Leaf,
      title: 'Environmental Initiatives',
      description: 'Contribute to tree plantation and environmental conservation efforts.',
      amount: '₹750'
    }
  ];

  const whyDonate = [
    {
      title: '100% Transparent Utilization',
      description: 'Every rupee you donate is utilized transparently with regular impact reports.'
    },
    {
      title: 'Direct Community Impact',
      description: 'Your contribution directly reaches the communities that need it most.'
    },
    {
      title: 'Regular Impact Updates',
      description: 'Receive regular updates on how your donation is making a difference.'
    },
    {
      title: 'Tax Benefits',
      description: 'Donations to registered NGOs are eligible for tax deductions under Section 80G.'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-primary/10 to-background">
        <div className="container">
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6">Support a Cause</h1>
          <p className="text-2xl font-semibold text-primary mb-4">Change a Life</p>
          <p className="text-xl text-muted-foreground max-w-3xl">
            Your contribution helps us deliver education, healthcare, empowerment, and sustainability programs where they are needed the most. Together, we can create lasting change.
          </p>
        </div>
      </section>

      {/* Donation Options */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <h2 className="section-title text-center mb-12">You Can Support</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {donationOptions.map((option, index) => {
              const Icon = option.icon;
              return (
                <div key={index} className="card-warm">
                  <div className="p-3 bg-primary/10 rounded-lg w-fit mb-4">
                    <Icon className="text-primary" size={32} />
                  </div>
                  <h3 className="text-lg font-bold mb-2">{option.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{option.description}</p>
                  <div className="text-2xl font-bold text-primary">{option.amount}</div>
                </div>
              );
            })}
          </div>

          <div className="text-center">
            <Button className="btn-primary text-lg px-10 py-6">
              Donate Now
            </Button>
            <p className="text-muted-foreground mt-4">
              You can also donate any custom amount. All donations are secure and confidential.
            </p>
          </div>
        </div>
      </section>

      {/* Why Donate Section */}
      <section className="py-16 md:py-24 bg-card">
        <div className="container">
          <h2 className="section-title text-center mb-12">Why Donate?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {whyDonate.map((reason, index) => (
              <div key={index} className="card-warm">
                <h3 className="text-xl font-bold mb-3">{reason.title}</h3>
                <p className="text-muted-foreground">{reason.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Impact Stories */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <h2 className="section-title text-center mb-12">Your Impact</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="card-warm text-center">
              <div className="text-5xl font-bold text-primary mb-3">₹500</div>
              <p className="text-muted-foreground">Provides books and materials for one child for a month</p>
            </div>
            <div className="card-warm text-center">
              <div className="text-5xl font-bold text-secondary mb-3">₹2000</div>
              <p className="text-muted-foreground">Supports a health camp for 50 community members</p>
            </div>
            <div className="card-warm text-center">
              <div className="text-5xl font-bold text-accent mb-3">₹5000</div>
              <p className="text-muted-foreground">Enables skill training for one woman for 3 months</p>
            </div>
          </div>
        </div>
      </section>

      {/* Donation Methods */}
      <section className="py-16 md:py-24 bg-card">
        <div className="container">
          <h2 className="section-title text-center mb-12">Donation Methods</h2>
          <div className="max-w-2xl mx-auto">
            <div className="space-y-4">
              <div className="border border-border rounded-lg p-6">
                <h3 className="font-bold text-lg mb-2">Online Donation</h3>
                <p className="text-muted-foreground mb-3">Secure online payment through our website</p>
                <Button className="btn-primary">Donate Online</Button>
              </div>
              <div className="border border-border rounded-lg p-6">
                <h3 className="font-bold text-lg mb-2">Bank Transfer</h3>
                <p className="text-muted-foreground mb-3">Direct bank transfer to our account</p>
                <p className="text-sm text-muted-foreground">Contact us for bank details: Sarishtikalyanfoundation@gmail.com</p>
              </div>
              <div className="border border-border rounded-lg p-6">
                <h3 className="font-bold text-lg mb-2">Cheque/DD</h3>
                <p className="text-muted-foreground mb-3">Send cheque or demand draft to our address</p>
                <p className="text-sm text-muted-foreground">Sristi Kalyan Foundation</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tax Benefits */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold mb-4">Tax Benefits</h2>
            <p className="text-lg text-muted-foreground mb-4">
              Sristi Kalyan Foundation is a registered NGO with 80G and 12A certifications. Your donations are eligible for tax deductions under Section 80G of the Income Tax Act.
            </p>
            <p className="text-muted-foreground">
              Please provide your PAN details while making a donation to claim tax benefits. You will receive a donation receipt with our 80G registration number.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-primary text-primary-foreground">
        <div className="container text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Every Donation Matters
          </h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Your generosity enables us to continue our mission of empowering underprivileged communities. Together, we can create lasting change.
          </p>
          <Button className="bg-primary-foreground text-primary hover:bg-primary-foreground/80 px-8 py-6 text-lg font-semibold">
            Donate Now
          </Button>
        </div>
      </section>
    </div>
  );
}
