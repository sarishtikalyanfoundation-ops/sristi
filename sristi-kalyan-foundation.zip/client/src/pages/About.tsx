import { Heart, Target, Compass, Shield } from 'lucide-react';

export default function About() {
  const values = [
    {
      icon: Shield,
      title: 'Integrity & Transparency',
      description: 'We operate with complete transparency and ethical standards in all our activities.'
    },
    {
      icon: Heart,
      title: 'Compassion & Inclusion',
      description: 'We believe in inclusive development that reaches every individual regardless of background.'
    },
    {
      icon: Target,
      title: 'Accountability & Impact',
      description: 'We are accountable for the impact we create and measure our success by community outcomes.'
    },
    {
      icon: Compass,
      title: 'Sustainability & Innovation',
      description: 'We focus on sustainable solutions and innovative approaches to social challenges.'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-primary/10 to-background">
        <div className="container">
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6">About Us</h1>
          <p className="text-xl text-muted-foreground max-w-3xl">
            Sristi Kalyan Foundation is a registered non-governmental organization working towards inclusive social development. We collaborate with communities, volunteers, donors, and partners to address critical social challenges faced by marginalized sections of society.
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="section-title mb-6">Our Mission</h2>
              <p className="text-lg text-muted-foreground mb-6">
                To empower underprivileged communities by enabling access to education, healthcare, women empowerment, and environmental sustainability, fostering self-reliance and social equity.
              </p>
              <p className="text-lg text-muted-foreground">
                We work at the grassroots level to transform lives with dignity, equality, and opportunity. Our mission is rooted in the belief that every individual deserves access to basic services and the opportunity to build a better life.
              </p>
            </div>
            <div className="bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg p-8 h-80 flex items-center justify-center">
              <div className="text-center">
                <Target className="text-primary mx-auto mb-4" size={64} />
                <p className="text-lg font-semibold text-foreground">Empowering Communities</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Vision Section */}
      <section className="py-16 md:py-24 bg-card">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="bg-gradient-to-br from-secondary/20 to-accent/20 rounded-lg p-8 h-80 flex items-center justify-center order-2 md:order-1">
              <div className="text-center">
                <Compass className="text-secondary mx-auto mb-4" size={64} />
                <p className="text-lg font-semibold text-foreground">Building a Just Society</p>
              </div>
            </div>
            <div className="order-1 md:order-2">
              <h2 className="section-title mb-6">Our Vision</h2>
              <p className="text-lg text-muted-foreground mb-6">
                To build a socially just and empowered India where every individual has equal access to opportunities, dignity, and a healthy environment.
              </p>
              <p className="text-lg text-muted-foreground">
                A future where compassion meets action and development reaches the last mile. We envision a society where no one is left behind, and where sustainable development benefits all.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <h2 className="section-title text-center mb-12">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <div key={index} className="card-warm">
                  <div className="p-3 bg-primary/10 rounded-lg w-fit mb-4">
                    <Icon className="text-primary" size={32} />
                  </div>
                  <h3 className="text-xl font-bold mb-3">{value.title}</h3>
                  <p className="text-muted-foreground">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Impact Section */}
      <section className="py-16 md:py-24 bg-card">
        <div className="container">
          <h2 className="section-title text-center mb-12">Our Impact</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-5xl font-bold text-primary mb-3">1000+</div>
              <p className="text-lg text-muted-foreground">Children Educated</p>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-secondary mb-3">500+</div>
              <p className="text-lg text-muted-foreground">Women Empowered</p>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-accent mb-3">5000+</div>
              <p className="text-lg text-muted-foreground">Lives Impacted</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
