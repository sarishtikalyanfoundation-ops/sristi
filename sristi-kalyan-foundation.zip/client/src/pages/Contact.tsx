import { useState } from 'react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-primary/10 to-background">
        <div className="container">
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6">Get in Touch</h1>
          <p className="text-xl text-muted-foreground max-w-3xl">
            We would love to hear from you. Whether you have questions, want to volunteer, or discuss partnership opportunities, please reach out to us.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Contact Information */}
            <div className="lg:col-span-1">
              <h2 className="text-2xl font-bold mb-8">Contact Information</h2>

              <div className="space-y-8">
                <div className="flex gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg h-fit">
                    <Phone className="text-primary" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold mb-1">Phone</h3>
                    <a href="tel:+919110596321" className="text-muted-foreground hover:text-primary transition-colors">
                      +91-9110596321
                    </a>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="p-3 bg-secondary/10 rounded-lg h-fit">
                    <Mail className="text-secondary" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold mb-1">Email</h3>
                    <a href="mailto:Sarishtikalyanfoundation@gmail.com" className="text-muted-foreground hover:text-secondary transition-colors break-all">
                      Sarishtikalyanfoundation@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="p-3 bg-accent/10 rounded-lg h-fit">
                    <MapPin className="text-accent" size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold mb-1">Address</h3>
                    <p className="text-muted-foreground">
                      Sristi Kalyan Foundation<br />
                      Working across communities in India
                    </p>
                  </div>
                </div>
              </div>

              {/* Social Links */}
              <div className="mt-12">
                <h3 className="font-bold mb-4">Follow Us</h3>
                <div className="flex gap-4">
                  <a href="#" className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-all">
                    <span className="font-bold">f</span>
                  </a>
                  <a href="#" className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-all">
                    <span className="font-bold">in</span>
                  </a>
                  <a href="#" className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-all">
                    <span className="font-bold">@</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <div className="card-warm">
                <h2 className="text-2xl font-bold mb-6">Send us a Message</h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-semibold mb-2">Name</label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="Your name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-2">Email</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="your@email.com"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-semibold mb-2">Phone</label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="+91-XXXXXXXXXX"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-2">Subject</label>
                      <select
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                      >
                        <option value="">Select a subject</option>\n                        <option value="volunteer">Volunteer Inquiry</option>
                        <option value="partnership">Partnership Opportunity</option>
                        <option value="donation">Donation Query</option>
                        <option value="feedback">Feedback</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold mb-2">Message</label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={6}
                      className="w-full px-4 py-3 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                      placeholder="Your message..."
                    />
                  </div>

                  <Button className="btn-primary w-full flex items-center justify-center gap-2">
                    <Send size={18} />
                    Send Message
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 md:py-24 bg-card">
        <div className="container max-w-3xl">
          <h2 className="section-title text-center mb-12">Frequently Asked Questions</h2>
          <div className="space-y-6">
            <div className="card-warm">
              <h3 className="font-bold text-lg mb-2">How can I volunteer with Sristi Kalyan Foundation?</h3>
              <p className="text-muted-foreground">
                You can fill out our volunteer form on the Get Involved page or contact us directly. We have various opportunities based on your skills and availability.
              </p>
            </div>
            <div className="card-warm">
              <h3 className="font-bold text-lg mb-2">Is my donation tax-deductible?</h3>
              <p className="text-muted-foreground">
                Yes! Sristi Kalyan Foundation is registered with 80G and 12A certifications. Your donations are eligible for tax deductions under Section 80G of the Income Tax Act.
              </p>
            </div>
            <div className="card-warm">
              <h3 className="font-bold text-lg mb-2">How can I track the impact of my donation?</h3>
              <p className="text-muted-foreground">
                We provide regular impact reports to our donors. You will receive updates on how your contribution is making a difference in the communities we serve.
              </p>
            </div>
            <div className="card-warm">
              <h3 className="font-bold text-lg mb-2">What are the partnership opportunities?</h3>
              <p className="text-muted-foreground">
                We welcome partnerships in CSR projects, community development, skill development, and healthcare initiatives. Please contact us to discuss potential collaboration.
              </p>
            </div>
            <div className="card-warm">
              <h3 className="font-bold text-lg mb-2">How transparent is the organization?</h3>
              <p className="text-muted-foreground">
                We maintain complete transparency in all operations. We provide detailed financial reports, impact assessments, and regular updates to all stakeholders.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
