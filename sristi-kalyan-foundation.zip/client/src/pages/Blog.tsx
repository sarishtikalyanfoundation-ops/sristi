import { Calendar, User, ArrowRight } from 'lucide-react';

export default function Blog() {
  const blogPosts = [
    {
      id: 1,
      title: 'How Education Transforms Lives: A Success Story',
      category: 'Education Stories',
      date: 'Feb 20, 2026',
      author: 'Sristi Kalyan Team',
      excerpt: 'Meet Priya, a 12-year-old girl whose life changed through our education program. From struggling in school to becoming a top performer...',
      image: 'https://private-us-east-1.manuscdn.com/sessionFile/zJEFH5twc4hB8R1C6VhpWI/sandbox/dPEwpQJePLmKf3q1zJ7e70-img-2_1772090161000_na1fn_ZWR1Y2F0aW9uLXNlY3Rpb24.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvekpFRkg1dHdjNGhCOFIxQzZWaHBXSS9zYW5kYm94L2RQRXdwUUplUExtS2YzcTF6SjdlNzAtaW1nLTJfMTc3MjA5MDE2MTAwMF9uYTFmbl9aV1IxWTJGMGFXOXVMWE5sWTNScGIyNC5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=g2iRaWwjY4i9a~aCoE11HlDfkMUAl9UmGNcuCnHOX4fWH-dzG~D-u9FXZEWGMknNQSExnzkIq7AOKTqRROFqrUdjailmXex96pw37MQwVCNLZ6E2veeGtvIDstrvBdn9EG6P7LaSab12aRydd2j6e4ok92bl~ArminoJv3WekEKdB3PFzbmPAv2~~hsLczYExtu5vLD-AQBPs9ohjd5xTPlPJTB9U19w3BLjSZTjGqmE7NzLzeulzJTalSSFNzPeMU5U5DQ5cxCOiby~FoamMP2OKiyciSEmdyNqsu9h4DiT1ND~Hob8we9qH8ulJck1d5ntHrJSMAAHQI7ogn70yg__'
    },
    {
      id: 2,
      title: 'Women Entrepreneurs: Building Dreams Together',
      category: 'Women Empowerment',
      date: 'Feb 15, 2026',
      author: 'Sristi Kalyan Team',
      excerpt: 'Our self-help group initiative has enabled 50 women to start their own businesses. Learn about their inspiring journey...',
      image: 'https://private-us-east-1.manuscdn.com/sessionFile/zJEFH5twc4hB8R1C6VhpWI/sandbox/dPEwpQJePLmKf3q1zJ7e70-img-3_1772090157000_na1fn_d29tZW4tZW1wb3dlcm1lbnQ.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvekpFRkg1dHdjNGhCOFIxQzZWaHBXSS9zYW5kYm94L2RQRXdwUUplUExtS2YzcTF6SjdlNzAtaW1nLTNfMTc3MjA5MDE1NzAwMF9uYTFmbl9kMjl0Wlc0dFpXMXdiM2RsY20xbGJuUS5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=vgBg5vpOyM9RtMlNhlXg69bS1qN3u-yJyIv469yQqjOTgMAlyjBmtBQy7x8qjAJxnMRrY0vOGkfDg2ISHZgqnwQXQl9nWWQ8j17UN63xXObsKQcwEvA-xqiH0c~eDciu3GlSjXd78vRcM4s-jmIz9lGxnoPhIYTgZrcto0HU-pfGqYrhiEYpNTK1zIkWzbSAmC-2fBxs1zLihQ~TWLN5w0RQ4DrgeU28igADSwScGBbfEbSyIw0LB7Lsvr1gN8pyZfV7-LJSXMowtGRQ5VkRQ97zXtGtDnG63d~52d1VRd3Hcj0AtkQqmET7RchgAX92865Fe7WRNCyvnjoN5DLtTg__'
    },
    {
      id: 3,
      title: 'Health Awareness: Nutrition for Better Lives',
      category: 'Health & Wellness',
      date: 'Feb 10, 2026',
      author: 'Sristi Kalyan Team',
      excerpt: 'Our nutrition awareness program reached 200 families this month. Discover the importance of proper nutrition...',
      image: 'https://private-us-east-1.manuscdn.com/sessionFile/zJEFH5twc4hB8R1C6VhpWI/sandbox/dPEwpQJePLmKf3q1zJ7e70-img-4_1772090163000_na1fn_aGVhbHRoLXdlbGxuZXNz.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvekpFRkg1dHdjNGhCOFIxQzZWaHBXSS9zYW5kYm94L2RQRXdwUUplUExtS2YzcTF6SjdlNzAtaW1nLTRfMTc3MjA5MDE2MzAwMF9uYTFmbl9hR1ZoYkhSb0xYZGxiR3h1WlhOei5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=tlwj85J~jSf9ZgenQfsDzCygDMHOmi94p8JpnfD3kCz3n2p3NPjsPq6PE6LlUtpi3c5-Vgjye5wJ3-PwVcLTXr4VtJ7JyQ2grZzmRJZmzhuwuNAt7TN4qob5hgNucXnVGB~5CVFpeEPlBZfVoMzry27GWAXbwhmgQPpae6ouEM-P4rgFyTT2oqibbJWHjQ6MB2FzQyixrxBEVbW5MeyZ~UdAVSvCOHPlFJwhMku-WGitX9WKTbGteqSf-pUO9LtVUJ~ukpau9TkV3ow4YwlV60lPcOyvKBLllq6bIBoKBMN8W5gqS0qh9yl-tGhkb5PztC5M0r15Fdc3l0fAH6NEKA__'
    },
    {
      id: 4,
      title: 'Green Initiative: Planting Hope for Tomorrow',
      category: 'Environment Awareness',
      date: 'Feb 5, 2026',
      author: 'Sristi Kalyan Team',
      excerpt: 'We planted 1000 trees this month! Learn how environmental conservation is creating a greener future...',
      image: 'https://private-us-east-1.manuscdn.com/sessionFile/zJEFH5twc4hB8R1C6VhpWI/sandbox/dPEwpQJePLmKf3q1zJ7e70-img-5_1772090161000_na1fn_ZW52aXJvbm1lbnQtc3VzdGFpbmFiaWxpdHk.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvekpFRkg1dHdjNGhCOFIxQzZWaHBXSS9zYW5kYm94L2RQRXdwUUplUExtS2YzcTF6SjdlNzAtaW1nLTVfMTc3MjA5MDE2MTAwMF9uYTFmbl9aVzUyYVhKdmJtMWxiblF0YzNWemRHRnBibUZpYVd4cGRIay5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=RzudDaYzI2voWgeg92LHVUu5v12IXuKGU4zlPzmz7hTsrIJrTA~Hf-~410OxCp~wBNSHcT9WRWmVoG5oKPfyQclxq4tIcPynwkT8MuCyIEqvHBqJ89k~Pe7r5AiSeO5tHogmz8RIzPMb62stajdRUSo~HedANUOqfQiQrCUvLkcO3sm-THZ03HKjpiE288CwgzQ8jCUFFXKHNhVdagzsJI2akU5I2IyChEp~OF4L5EUiR7lzvrvUgXWiS8A7uwxwrGkRZIEc2vzuCwZ4hHXZRQl~aYHvRk80stK0rU0Stprcq3ItsKjVNk252Bu8beIZymUstjez8Yhga0M~DlGEJA__'
    }
  ];

  const categories = [
    'All Posts',
    'Education Stories',
    'Women Empowerment',
    'Health & Wellness',
    'Environment Awareness',
    'NGO Updates'
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-b from-accent/10 to-background">
        <div className="container">
          <h1 className="text-5xl md:text-6xl font-bold text-foreground mb-6">Our Stories & Updates</h1>
          <p className="text-xl text-muted-foreground max-w-3xl">
            Stay updated with our on-ground activities, success stories, awareness articles, and campaign highlights. Read about the real impact we are creating in communities.
          </p>
        </div>
      </section>

      {/* Categories */}
      <section className="py-8 bg-card border-b border-border">
        <div className="container">
          <div className="flex flex-wrap gap-3">
            {categories.map((category, index) => (
              <button
                key={index}
                className={`px-4 py-2 rounded-full font-medium transition-all ${
                  index === 0
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-foreground hover:bg-primary/20'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="space-y-8">
            {blogPosts.map((post) => (
              <article key={post.id} className="card-warm overflow-hidden hover:shadow-xl transition-shadow">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-1 h-48 md:h-auto">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover rounded-lg"
                    />
                  </div>
                  <div className="md:col-span-2 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-4 mb-3">
                        <span className="inline-block px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-semibold">
                          {post.category}
                        </span>
                        <span className="text-sm text-muted-foreground">{post.date}</span>
                      </div>
                      <h2 className="text-2xl font-bold mb-3 hover:text-primary transition-colors cursor-pointer">
                        {post.title}
                      </h2>
                      <p className="text-muted-foreground mb-4">{post.excerpt}</p>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <User size={16} />
                        {post.author}
                      </div>
                      <button className="flex items-center gap-2 text-primary font-semibold hover:gap-3 transition-all">
                        Read More <ArrowRight size={18} />
                      </button>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>

          {/* Pagination */}
          <div className="flex justify-center gap-2 mt-12">
            <button className="px-4 py-2 rounded-lg bg-primary text-primary-foreground font-semibold">1</button>
            <button className="px-4 py-2 rounded-lg bg-muted text-foreground hover:bg-primary/20 transition-colors">2</button>
            <button className="px-4 py-2 rounded-lg bg-muted text-foreground hover:bg-primary/20 transition-colors">3</button>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 md:py-24 bg-card">
        <div className="container max-w-2xl">
          <div className="text-center">
            <h2 className="text-4xl font-bold mb-4">Stay Updated</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Subscribe to our newsletter to receive updates on our programs, impact stories, and upcoming events.
            </p>
            <div className="flex gap-3">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <button className="btn-primary px-6 py-3">Subscribe</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
